<?php
$host = 'localhost';
$dbname = 'smsenvoi_cellvoz_api';
$user = 'smsenvoi_smsadmin';
$password = '8QBwJje^e+Nk';

try {
    $dsn = "mysql:host=$host;dbname=$dbname";
    $conn = new PDO($dsn, $user, $password);
} catch (PDOException $e){
    die("Conexion fallida: " . $e->getMessage());
}